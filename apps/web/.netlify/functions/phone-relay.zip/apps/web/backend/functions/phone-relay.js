var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/functions/phone-relay.mjs
var phone_relay_exports = {};
__export(phone_relay_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(phone_relay_exports);
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Relay-Secret, Authorization"
};
var FB_PROJECT = "onetaskonly-app";
var FB_API_KEY = "AIzaSyB5UiDE9s0xjWeYa4OQ1LLJ63EwPVoSLrA";
var FS_BASE = `https://firestore.googleapis.com/v1/projects/${FB_PROJECT}/databases/(default)/documents/phone-relay`;
function ok(body) {
  return {
    statusCode: 200,
    headers: { ...CORS, "Content-Type": "application/json" },
    body: typeof body === "string" ? body : JSON.stringify(body)
  };
}
function err(statusCode, msg) {
  return {
    statusCode,
    headers: { ...CORS, "Content-Type": "application/json" },
    body: JSON.stringify({ error: msg })
  };
}
async function fsGet(docId, idToken = null) {
  const url = `${FS_BASE}/${docId}?key=${FB_API_KEY}`;
  const headers = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(url, { headers });
  if (res.status === 404) return null;
  if (res.status === 401) throw new Error("auth:token_invalid");
  if (res.status === 403) throw new Error("auth:firestore_denied");
  if (!res.ok) throw new Error(`Firestore GET ${docId} \u2192 HTTP ${res.status}`);
  const json = await res.json();
  return json.fields?.data?.stringValue ?? null;
}
async function fsSet(docId, value) {
  const url = `${FS_BASE}/${docId}?key=${FB_API_KEY}&updateMask.fieldPaths=data`;
  const res = await fetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fields: { data: { stringValue: value } } })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Firestore PATCH ${docId} \u2192 HTTP ${res.status}: ${text}`);
  }
}
function extractIdToken(event) {
  const authHeader = event.headers["authorization"] || event.headers["Authorization"] || "";
  if (!authHeader.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7).trim();
  return token || null;
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }
  const action = (event.queryStringParameters?.action || "").toLowerCase();
  const method = event.httpMethod;
  const secret = process.env.PHONE_RELAY_SECRET || "";
  const incoming = event.headers["x-relay-secret"] || event.headers["X-Relay-Secret"] || "";
  if (action === "state" && method === "GET") {
    const idToken = extractIdToken(event);
    if (!idToken) return err(401, "Firebase ID token required \u2014 sign in to access phone data");
    try {
      const state = await fsGet("state", idToken);
      if (!state) return err(404, "No state \u2014 DeskPhone has not pushed yet");
      return ok(state);
    } catch (e) {
      if (e.message === "auth:token_invalid") return err(401, "Invalid or expired Firebase token \u2014 sign in again");
      if (e.message === "auth:firestore_denied") return err(403, "Firestore security rules denied access \u2014 set allow read: if request.auth != null for phone-relay/state");
      return err(500, "Failed to read state: " + e.message);
    }
  }
  if (action === "push" && method === "POST") {
    if (!secret || incoming !== secret) return err(401, "unauthorized");
    const body = event.body || "";
    if (!body) return err(400, "empty body");
    try {
      await fsSet("state", body);
      return ok({ ok: true });
    } catch (e) {
      return err(500, "Failed to write state: " + e.message);
    }
  }
  if (action === "command" && method === "POST") {
    const idToken = extractIdToken(event);
    if (!idToken) return err(401, "Firebase ID token required \u2014 sign in to queue commands");
    let cmd;
    try {
      cmd = JSON.parse(event.body || "{}");
    } catch {
      return err(400, "invalid JSON");
    }
    if (!cmd.path) return err(400, "missing path");
    cmd.id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    cmd.queuedAt = Date.now();
    try {
      const existing = JSON.parse(await fsGet("commands") || "[]");
      existing.push(cmd);
      const capped = existing.slice(-50);
      await fsSet("commands", JSON.stringify(capped));
      return ok({ ok: true, id: cmd.id });
    } catch (e) {
      return err(500, "Failed to queue command: " + e.message);
    }
  }
  if (action === "drain" && method === "GET") {
    if (!secret || incoming !== secret) return err(401, "unauthorized");
    try {
      const commands = JSON.parse(await fsGet("commands") || "[]");
      if (commands.length > 0) await fsSet("commands", JSON.stringify([]));
      return ok(commands);
    } catch (e) {
      return err(500, "Failed to drain commands: " + e.message);
    }
  }
  return err(400, `unknown action '${action}' for ${method}`);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
